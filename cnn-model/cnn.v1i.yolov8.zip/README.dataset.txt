# cnn > 2025-11-18 10:11pm
https://universe.roboflow.com/yolo-wamhn/cnn-qepyy

Provided by a Roboflow user
License: CC BY 4.0

